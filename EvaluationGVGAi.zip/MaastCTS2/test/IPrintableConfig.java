package MaastCTS2.test;

public interface IPrintableConfig {
	public String getConfigDataString();
	public String getName();
}
