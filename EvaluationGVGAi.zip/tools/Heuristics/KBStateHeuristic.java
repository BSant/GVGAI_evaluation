package tracks.singlePlayer.tools.Heuristics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeSet;

import core.game.Event;
import core.game.Observation;
import core.game.StateObservation;
import ontology.Types;
import tools.Vector2d;

public class KBStateHeuristic extends StateHeuristic {

	public boolean allSprites = true;
	public boolean manhatanDistance = true;
	
    private static final double HUGE_NEGATIVE = -1000000.0;
    private static final double HUGE_POSITIVE =  1000000.0;

    public int blockSize;
    public double multiplyer = .001;
    public DistCalculator Distances;
   
   
    public KBStateHeuristic(StateObservation stateObs) {
        Sprites = new HashMap<Integer, Double>();
        blockSize = stateObs.getBlockSize();
		if(manhatanDistance) Distances = new DistCalculator(stateObs);
       
        Vector2d avatarPosition = stateObs.getAvatarPosition();
       
        ArrayList<Observation>[] obsVecMovable = stateObs.getMovablePositions(avatarPosition);
        if(obsVecMovable != null)for(ArrayList<Observation> obs : obsVecMovable){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               }   
           }

        ArrayList<Observation>[] obsVecNPC = stateObs.getNPCPositions(avatarPosition);
        if(obsVecNPC != null) for(ArrayList<Observation> obs : obsVecNPC){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
            }   
        }
       
        ArrayList<Observation>[] obsVecPortal = stateObs.getPortalsPositions(avatarPosition);
        if(obsVecPortal != null) for(ArrayList<Observation> obs : obsVecPortal){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
            }   
        }
           
       
        ArrayList<Observation>[] obsVecResource = stateObs.getResourcesPositions(avatarPosition);
        if(obsVecResource != null) for(ArrayList<Observation> obs : obsVecResource){
               if(obs.size() > 0){
                int type = obs.get(0).itype;
                if(!Sprites.containsKey(type))Sprites.put(type, 1.0);   
            }
        }
    }

    public double evaluateState(StateObservation stateObs){
        boolean gameOver = stateObs.isGameOver();
        Types.WINNER win = stateObs.getGameWinner();
        double score = stateObs.getGameScore();
       
        TreeSet<Event> tree = stateObs.getEventsHistory();
        for(Event e: tree){
            if(e.gameStep == stateObs.getGameTick()-1){
                int type = e.passiveTypeId;
                if(!Sprites.containsKey(type))Sprites.put(type, 1.0);
                if(gameOver && win == Types.WINNER.PLAYER_LOSES){
                    Sprites.replace(type, -10.0);
                    return HUGE_NEGATIVE;
                }else if(gameOver && win == Types.WINNER.PLAYER_WINS){
                    Sprites.replace(type, 10.0);
                    return HUGE_POSITIVE;
                }else if(stateObs.getGameScore() > this.prevScore){
                    Sprites.replace(type, 1.0);
                }if(stateObs.getGameScore() == this.prevScore){
                    Sprites.replace(type, 0.0);
                }if(stateObs.getGameScore() < this.prevScore){
                    Sprites.replace(type, -1.0);
                }
          //      System.out.println(type+":"+Sprites.get(type));
            }
        }
       
        /*
         * Actualize weight from explored sprites.
         */
       
        Vector2d avatarPosition = stateObs.getAvatarPosition();       
   
        ArrayList<Observation>[][] obsGrid = stateObs.getObservationGrid();
        int xAvatarGrid = (int) (avatarPosition.x/blockSize);
        int yAvatarGrid = (int) (avatarPosition.y/blockSize);
    	if(avatarPosition.x < stateObs.getWorldDimension().width && avatarPosition.x >= 0 &&
    			avatarPosition.y < stateObs.getWorldDimension().height && avatarPosition.y >=0)
        for(int i=0;i<obsGrid[xAvatarGrid][yAvatarGrid].size();i++){
            int type = obsGrid[xAvatarGrid][yAvatarGrid].get(i).itype;

            if(!Sprites.containsKey(type))Sprites.put(type, 1.0);
                if(gameOver && win == Types.WINNER.PLAYER_LOSES){
                    Sprites.replace(type, -10.0);
                    return HUGE_NEGATIVE;
                }else if(gameOver && win == Types.WINNER.PLAYER_WINS){
                    Sprites.replace(type, +10.0);
                    return HUGE_POSITIVE;
                }else if(stateObs.getGameScore() > this.prevScore){
                    Sprites.replace(type, 1.0);
                }if(stateObs.getGameScore() == this.prevScore){
                    Sprites.replace(type, 0.0);
                }if(stateObs.getGameScore() < this.prevScore){
                    Sprites.replace(type, -1.0);
                }
           //     System.out.println(type+":"+Sprites.get(type));
           
        }
       
        ArrayList<Observation>[] obsVecMovable = stateObs.getMovablePositions(avatarPosition);
        if(obsVecMovable != null)for(ArrayList<Observation> obs : obsVecMovable){
        	int i = 0;
            if(obs.size() > i){
                int type = obs.get(i).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
                if(allSprites)
                	for(;i<obs.size();i++){
                		Vector2d position = obs.get(i).position;
                		int tgX = (int)position.x/blockSize;
                		int tgY = (int)position.y/blockSize;
                		
                		if(manhatanDistance)
                			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
                		else
                			score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
                	}
                else{
                	Vector2d position = obs.get(i).position;
        			int tgX = (int)position.x/blockSize;
        			int tgY = (int)position.y/blockSize;
                	
        			if(manhatanDistance)
            			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
            		else
                		score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               }
           }
        }

        ArrayList<Observation>[] obsVecNPC = stateObs.getNPCPositions(avatarPosition);
        if(obsVecNPC != null) for(ArrayList<Observation> obs : obsVecNPC){
        	int i = 0;
            if(obs.size() > i){
                int type = obs.get(i).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
                if(allSprites)
                	for(;i<obs.size();i++){
                		Vector2d position = obs.get(i).position;
                		int tgX = (int)position.x/blockSize;
                		int tgY = (int)position.y/blockSize;
                		
                		if(manhatanDistance)
                			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
                		else
                			score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
                	}
                else{
                	Vector2d position = obs.get(i).position;
        			int tgX = (int)position.x/blockSize;
        			int tgY = (int)position.y/blockSize;
                	
        			if(manhatanDistance)
            			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
            		else
                		score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               }
           }
        }
       
        ArrayList<Observation>[] obsVecPortal = stateObs.getPortalsPositions(avatarPosition);
        if(obsVecPortal != null) for(ArrayList<Observation> obs : obsVecPortal){
        	int i = 0;
            if(obs.size() > i){
                int type = obs.get(i).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
                if(allSprites)
                	for(;i<obs.size();i++){
                		Vector2d position = obs.get(i).position;
                		int tgX = (int)position.x/blockSize;
                		int tgY = (int)position.y/blockSize;
                		
                		if(manhatanDistance)
                			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
                		else
                			score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
                	}
                else{
                	Vector2d position = obs.get(i).position;
        			int tgX = (int)position.x/blockSize;
        			int tgY = (int)position.y/blockSize;
                	
        			if(manhatanDistance)
            			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
            		else
                		score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               }
           }
        }
           
       
        ArrayList<Observation>[] obsVecResource = stateObs.getResourcesPositions(avatarPosition);
        if(obsVecResource != null) for(ArrayList<Observation> obs : obsVecResource){
        	int i = 0;
            if(obs.size() > i){
                int type = obs.get(i).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
                if(allSprites)
                	for(;i<obs.size();i++){
                		Vector2d position = obs.get(i).position;
                		int tgX = (int)position.x/blockSize;
                		int tgY = (int)position.y/blockSize;
                		
                		if(manhatanDistance)
                			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
                		else
                			score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
                	}
                else{
                	Vector2d position = obs.get(i).position;
        			int tgX = (int)position.x/blockSize;
        			int tgY = (int)position.y/blockSize;
                	
        			if(manhatanDistance)
            			score -= Sprites.get(type)*multiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
            		else
                		score -= Sprites.get(type)*multiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               }
           }
        }

    //    System.out.println(score);
        return score;
    }


}