package tracks.singlePlayer.tools.Heuristics;

import java.awt.Dimension;
import java.util.ArrayList;

import core.game.Observation;
import core.game.StateObservation;
import ontology.Types;
import tools.Vector2d;


public class MatrixScoreHeuristic extends StateHeuristic{

    private static final double HUGE_NEGATIVE = -1000000.0;
    private static final double HUGE_POSITIVE =  1000000.0;

	public int blockSize;
	public double epsilon = 10;
	public double pointPrioritizer = 1;
    public double initialNpcCounter = 0;
    public int boardWidth;
    public int boardHeight;
    
    public MatrixScoreHeuristic(StateObservation stateObs) {
    	blockSize = stateObs.getBlockSize();
    	Dimension boardSize = stateObs.getWorldDimension();

    	//ArrayList<Observation>[][] obs = stateObs.getObservationGrid();
    	boardWidth = (int)boardSize.width/blockSize;
    	boardHeight = (int)boardSize.height/blockSize;
      	mat = new double[boardSize.width/blockSize+1][boardSize.height/blockSize+1];
    }

    public double evaluateState(StateObservation stateObs){
            boolean gameOver = stateObs.isGameOver();
            Types.WINNER win = stateObs.getGameWinner();
            double rawScore = pointPrioritizer*stateObs.getGameScore();

            if(gameOver && win == Types.WINNER.PLAYER_LOSES)
                return HUGE_NEGATIVE;

            if(gameOver && win == Types.WINNER.PLAYER_WINS)
                return HUGE_POSITIVE;

    		Vector2d avatarPos = stateObs.getAvatarPosition();

    		int width = (int) (avatarPos.x/blockSize);
    		int height = (int) (avatarPos.y/blockSize);
    		//System.out.println(avatarPos.x + " " + avatarPos.y);
    		if(width < 0 || height < 0){
                return HUGE_NEGATIVE;
    		}else{
    			mat[width][height] += 1;
    			rawScore -= mat[width][height]*epsilon;
    			
    		}
            return rawScore;
    }

}


