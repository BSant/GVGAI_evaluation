package tracks.singlePlayer.tools.Heuristics;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeSet;

import core.game.Event;
import core.game.Observation;
import core.game.StateObservation;
import ontology.Types;
import tools.Vector2d;

public class myHeuristic extends StateHeuristic {

	public boolean allSprites = true;
	public boolean manhatanDistance = true;
	public boolean KBevaluations = true;
	
	public boolean ExplorationMap = true;
	public boolean evaluationPenaltyOnly = true; // If false remember to update the matrix in the simulations 
	
	public boolean AvatarStatus = true; 
	
	
    private static final double HUGE_NEGATIVE = -1000000.0;
    private static final double HUGE_POSITIVE =  1000000.0;

    public int blockSize;
    public double KBmultiplyer  = .001;
    public double MATmultiplyer = .001;
    public double HPmultiplyer = .1;
    public double RESOURCEmultiplyer = .1;
    public DistCalculator Distances;
   
    HashMap<Integer,Integer> MaxResources;

    public int boardWidth;
    public int boardHeight;
   
    public myHeuristic(StateObservation stateObs) {
        Sprites = new HashMap<Integer, Double>();
        blockSize = stateObs.getBlockSize();        
    if(AvatarStatus){
    	this.MaxResources = new HashMap<Integer,Integer>();	
    }
    
    if(ExplorationMap) {

        Dimension boardSize = stateObs.getWorldDimension();
        
        boardWidth = (int)(boardSize.width/blockSize);
        boardHeight = (int)(boardSize.height/blockSize);
        mat = new double[(int)(boardSize.width/blockSize)][(int)(boardSize.height/blockSize)];
    	
    }
    
    if(KBevaluations) {
		if(manhatanDistance) Distances = new DistCalculator(stateObs);
	       
        Vector2d avatarPosition = stateObs.getAvatarPosition();
       
        ArrayList<Observation>[] obsVecMovable = stateObs.getMovablePositions(avatarPosition);
        if(obsVecMovable != null)for(ArrayList<Observation> obs : obsVecMovable){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               }   
           }

        ArrayList<Observation>[] obsVecNPC = stateObs.getNPCPositions(avatarPosition);
        if(obsVecNPC != null) for(ArrayList<Observation> obs : obsVecNPC){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
            }   
        }
       
        ArrayList<Observation>[] obsVecPortal = stateObs.getPortalsPositions(avatarPosition);
        if(obsVecPortal != null) for(ArrayList<Observation> obs : obsVecPortal){
            if(obs.size() > 0){
                   int type = obs.get(0).itype;
                if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
            }   
        }
           
       
        ArrayList<Observation>[] obsVecResource = stateObs.getResourcesPositions(avatarPosition);
        if(obsVecResource != null) for(ArrayList<Observation> obs : obsVecResource){
               if(obs.size() > 0){
                int type = obs.get(0).itype;
                if(!Sprites.containsKey(type))Sprites.put(type, 1.0);   
            }
        }
    }
    }

    public double evaluateState(StateObservation stateObs){
        boolean gameOver = stateObs.isGameOver();
        Types.WINNER win = stateObs.getGameWinner();
        double score = stateObs.getGameScore();
        Vector2d avatarPosition = stateObs.getAvatarPosition();       
        
   
   if(AvatarStatus) {
	   int hp = stateObs.getAvatarHealthPoints();
	   int minHP = stateObs.getAvatarLimitHealthPoints();
	   int maxHP = stateObs.getAvatarMaxHealthPoints();
	   
	   HashMap<Integer,Integer> resources = stateObs.getAvatarResources();
	  double Resources_sum = 0;
	   for(HashMap.Entry<Integer, Integer> entry:resources.entrySet()){
		   //System.out.println(entry.getKey() + ": " + entry.getValue());

		   if(!this.MaxResources.containsKey(entry.getKey())){
			   this.MaxResources.put(entry.getKey(), entry.getValue());
		   }else{
			   int max = this.MaxResources.get(entry.getKey());
			   if(max < entry.getValue()){
				   this.MaxResources.replace(entry.getKey(), entry.getValue());

			   }
		   }
		   Resources_sum += (double) entry.getValue()/this.MaxResources.get(entry.getKey());
	   }
	   if(resources.size() > 0)
		   score += this.RESOURCEmultiplyer * (Resources_sum/resources.size());
	   
	   if(maxHP > 0)
		   score -= this.HPmultiplyer * ((maxHP-hp)/maxHP);
   }
   
   if(ExplorationMap) {

       int width = (int) (avatarPosition.x/blockSize);
       int height = (int) (avatarPosition.y/blockSize);
       
       if(width >= 0 && height >= 0 && width < boardWidth && height < boardHeight ){
           if(evaluationPenaltyOnly) mat[width][height] += 1;
           score -= mat[width][height]*this.MATmultiplyer;
       }else{
    	   return HUGE_NEGATIVE;
       }
   }
        
   if(KBevaluations) {    
       TreeSet<Event> tree = stateObs.getEventsHistory();
       for(Event e: tree){
           if(e.gameStep == stateObs.getGameTick()-1){
               int type = e.passiveTypeId;
               if(!Sprites.containsKey(type))Sprites.put(type, 1.0);
               if(gameOver && win == Types.WINNER.PLAYER_LOSES){
                   Sprites.replace(type, -1.0);
                   return HUGE_NEGATIVE;
               }else if(gameOver && win == Types.WINNER.PLAYER_WINS){
                   Sprites.replace(type, 10.0);
                   return HUGE_POSITIVE;
               }else if(stateObs.getGameScore() > this.prevScore){
                   Sprites.replace(type, 1.0);
               }if(stateObs.getGameScore() == this.prevScore){
                   Sprites.replace(type, 0.0);
               }if(stateObs.getGameScore() < this.prevScore){
                   Sprites.replace(type, -1.0);
               }
         //      System.out.println(type+":"+Sprites.get(type));
           }
       }
      
       /*
        * Actualize weight from explored sprites.
        */
      
  
       ArrayList<Observation>[][] obsGrid = stateObs.getObservationGrid();
       int xAvatarGrid = (int) (avatarPosition.x/blockSize);
       int yAvatarGrid = (int) (avatarPosition.y/blockSize);
   	if(avatarPosition.x < stateObs.getWorldDimension().width && avatarPosition.x >= 0 &&
   			avatarPosition.y < stateObs.getWorldDimension().height && avatarPosition.y >=0)
       for(int i=0;i<obsGrid[xAvatarGrid][yAvatarGrid].size();i++){
           int type = obsGrid[xAvatarGrid][yAvatarGrid].get(i).itype;

           if(!Sprites.containsKey(type))Sprites.put(type, 1.0);
               if(gameOver && win == Types.WINNER.PLAYER_LOSES){
                   Sprites.replace(type, -10.0);
                   return HUGE_NEGATIVE;
               }else if(gameOver && win == Types.WINNER.PLAYER_WINS){
                   Sprites.replace(type, +10.0);
                   return HUGE_POSITIVE;
               }else if(stateObs.getGameScore() > this.prevScore){
                   Sprites.replace(type, 1.0);
               }if(stateObs.getGameScore() == this.prevScore){
                   Sprites.replace(type, 0.0);
               }if(stateObs.getGameScore() < this.prevScore){
                   Sprites.replace(type, -1.0);
               }
          //     System.out.println(type+":"+Sprites.get(type));
          
       }
      
       ArrayList<Observation>[] obsVecMovable = stateObs.getMovablePositions(avatarPosition);
       if(obsVecMovable != null)for(ArrayList<Observation> obs : obsVecMovable){
       	int i = 0;
           if(obs.size() > i){
               int type = obs.get(i).itype;
               if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               if(allSprites)
               	for(;i<obs.size();i++){
               		Vector2d position = obs.get(i).position;
               		int tgX = (int)position.x/blockSize;
               		int tgY = (int)position.y/blockSize;
               		
               		if(manhatanDistance)
               			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
               		else
               			score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               	}
               else{
               	Vector2d position = obs.get(i).position;
       			int tgX = (int)position.x/blockSize;
       			int tgY = (int)position.y/blockSize;
               	
       			if(manhatanDistance)
           			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
           		else
               		score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
              }
          }
       }

       ArrayList<Observation>[] obsVecNPC = stateObs.getNPCPositions(avatarPosition);
       if(obsVecNPC != null) for(ArrayList<Observation> obs : obsVecNPC){
       	int i = 0;
           if(obs.size() > i){
               int type = obs.get(i).itype;
               if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               if(allSprites)
               	for(;i<obs.size();i++){
               		Vector2d position = obs.get(i).position;
               		int tgX = (int)position.x/blockSize;
               		int tgY = (int)position.y/blockSize;
               		
               		if(manhatanDistance)
               			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
               		else
               			score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               	}
               else{
               	Vector2d position = obs.get(i).position;
       			int tgX = (int)position.x/blockSize;
       			int tgY = (int)position.y/blockSize;
               	
       			if(manhatanDistance)
           			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
           		else
               		score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
              }
          }
       }
      
       ArrayList<Observation>[] obsVecPortal = stateObs.getPortalsPositions(avatarPosition);
       if(obsVecPortal != null) for(ArrayList<Observation> obs : obsVecPortal){
       	int i = 0;
           if(obs.size() > i){
               int type = obs.get(i).itype;
               if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               if(allSprites)
               	for(;i<obs.size();i++){
               		Vector2d position = obs.get(i).position;
               		int tgX = (int)position.x/blockSize;
               		int tgY = (int)position.y/blockSize;
               		
               		if(manhatanDistance)
               			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
               		else
               			score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               	}
               else{
               	Vector2d position = obs.get(i).position;
       			int tgX = (int)position.x/blockSize;
       			int tgY = (int)position.y/blockSize;
               	
       			if(manhatanDistance)
           			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
           		else
               		score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
              }
          }
       }
          
      
       ArrayList<Observation>[] obsVecResource = stateObs.getResourcesPositions(avatarPosition);
       if(obsVecResource != null) for(ArrayList<Observation> obs : obsVecResource){
       	int i = 0;
           if(obs.size() > i){
               int type = obs.get(i).itype;
               if(!Sprites.containsKey(type)) Sprites.put(type, 1.0);
               if(allSprites)
               	for(;i<obs.size();i++){
               		Vector2d position = obs.get(i).position;
               		int tgX = (int)position.x/blockSize;
               		int tgY = (int)position.y/blockSize;
               		
               		if(manhatanDistance)
               			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
               		else
               			score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
               	}
               else{
               	Vector2d position = obs.get(i).position;
       			int tgX = (int)position.x/blockSize;
       			int tgY = (int)position.y/blockSize;
               	
       			if(manhatanDistance)
           			score -= Sprites.get(type)*KBmultiplyer*this.Distances.getDist(xAvatarGrid, yAvatarGrid,tgX, tgY);
           		else
               		score -= Sprites.get(type)*KBmultiplyer*((Math.abs(position.x-avatarPosition.x)+Math.abs(position.y-avatarPosition.y))/blockSize);
              }
          }
       }
   }
   		if(gameOver && win == Types.WINNER.PLAYER_LOSES) return HUGE_NEGATIVE;
   		else if(gameOver && win == Types.WINNER.PLAYER_WINS) return HUGE_POSITIVE;
   		else return score;
    }


}


