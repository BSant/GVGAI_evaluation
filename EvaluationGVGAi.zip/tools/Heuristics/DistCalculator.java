package tracks.singlePlayer.tools.Heuristics;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeSet;

import core.game.Event;
import core.game.Observation;
import core.game.StateObservation;
import ontology.Types;
import tools.Vector2d;

public class DistCalculator {

	public boolean verbose = false;
	
    public int blockSize;
    public int width;
    public int height;
    public int maxDist; 
    
    public int distanceMatrix[][][][];
    public int wallMatrix[][];
    
    
    public DistCalculator(StateObservation stateObs) {
        this.blockSize = stateObs.getBlockSize();
        Dimension dim = stateObs.getWorldDimension();
        ArrayList<Observation>[][] grid = stateObs.getObservationGrid();
        
        this.width = (int)(dim.width / this.blockSize);
        this.height = (int)(dim.height / this.blockSize);
        
        if(verbose)
        	System.out.println("map width/height :"+ this.width + "/"+ this.height);
        
        this.maxDist = this.width + this.height + 1;

        this.distanceMatrix = new int[this.width][this.height][this.width][this.height];
        this.wallMatrix = new int[this.width][this.height];

        for(int i =0; i< this.width;i++)
            for(int j =0; j< this.height;j++) {

            	for(Observation obs : grid[i][j]){
            		if(obs.itype == 0) {
            			this.wallMatrix[i][j] = 1;
            		}else{
            			this.wallMatrix[i][j] = 0;
            		}       		
            	}
            	
                for(int i2 =0; i2< this.width;i2++)
                for(int j2 =0; j2< this.height;j2++) 
                   		this.distanceMatrix[i][j][i2][j2] = this.distanceMatrix[i2][j2][i][j] =this.maxDist;

        		this.distanceMatrix[i][j][i][j] = 0;
        }
        
        for(int i =0; i< this.width;i++)
            for(int j =0; j< this.height;j++)
            	this.calculate(i, j);
        /*
          
        Vector2d v = stateObs.getAvatarPosition();
        int x = (int) v.x/this.blockSize;
        int y = (int) v.y/this.blockSize;
        this.calculate(x,y);
        
        ArrayList<Observation>[] imovable = stateObs.getImmovablePositions();

        for(ArrayList<Observation> aObs : imovable) {
        	for(Observation obs : aObs){
        		Vector2d p = obs.position;
        		x = (int) p.x/this.blockSize;
        		y = (int) p.y/this.blockSize;
        		
        		calculate(x,y);
        	}
        
    	}*/
     }
    
    private boolean isInGrid(int x,int y) {

    	
    	if(x<0) return false; 
    	if(x >= this.width) return false;
    	
    	if(y<0) return false; 
    	if(y >= this.height) return false;
    	return true;
    }
    
    private void calculate(int avatarX,int avatarY) {
    	ArrayList<Vector2d> next;
    	next= new ArrayList<Vector2d>();
    	Vector2d actual = new Vector2d(avatarX,avatarY);
    	next.add(actual);

    	if(verbose) 
    		System.out.println("Calculating all distances from position("+ avatarX + ","+ avatarY+")");
		
    	
    	while(next.size() > 0) {
    		actual = next.get(0);
    		int x = (int) actual.x;
    		int y = (int) actual.y;
    		
    		
    		if(isInGrid(x-1,y)) {
    			if(this.distanceMatrix[avatarX][avatarY][x][y] + 1 < this.distanceMatrix[avatarX][avatarY][x-1][y]) {
    				this.distanceMatrix[avatarX][avatarY][x-1][y] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				this.distanceMatrix[x-1][y][avatarX][avatarY] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				if(this.wallMatrix[x-1][y] != 1) {
    					Vector2d newCell = new Vector2d(x-1,y);
    		    		next.add(newCell);
    				}
    			}
    		}
    		
    		if(isInGrid(x+1,y)) {
    			if(this.distanceMatrix[avatarX][avatarY][x][y] + 1 < this.distanceMatrix[avatarX][avatarY][x+1][y]) {
    				this.distanceMatrix[avatarX][avatarY][x+1][y] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				this.distanceMatrix[x+1][y][avatarX][avatarY] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				if(this.wallMatrix[x+1][y] != 1) {
    					Vector2d newCell = new Vector2d(x+1,y);
    		    		next.add(newCell);
    				}
    			}
    		}
    		
    		if(isInGrid(x,y-1)) {
    			if(this.distanceMatrix[avatarX][avatarY][x][y] + 1 < this.distanceMatrix[avatarX][avatarY][x][y-1]) {
    				this.distanceMatrix[avatarX][avatarY][x][y-1] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				this.distanceMatrix[x][y-1][avatarX][avatarY] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				if(this.wallMatrix[x][y-1] != 1) {
    					Vector2d newCell = new Vector2d(x,y-1);
    		    		next.add(newCell);
    				}
    			}
    		}
    		
    		if(isInGrid(x,y+1)) {
    			if(this.distanceMatrix[avatarX][avatarY][x][y] + 1 < this.distanceMatrix[avatarX][avatarY][x][y+1]) {
    				this.distanceMatrix[avatarX][avatarY][x][y+1] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				this.distanceMatrix[x][y+1][avatarX][avatarY] = this.distanceMatrix[avatarX][avatarY][x][y] + 1;
    				if(this.wallMatrix[x][y+1] != 1) {
    					Vector2d newCell = new Vector2d(x,y+1);
    		    		next.add(newCell);
    				}
    			}
    		}
    		next.remove(0);
    	}
    	
    	
    }
    
    public int getDist(int avatarX,int avatarY,int targetX,int targetY) {
    
    	if(!this.isInGrid(avatarX, avatarY)) return this.maxDist;
    	if(!this.isInGrid(targetX, targetY)) return this.maxDist;
    	   	
		return this.distanceMatrix[avatarX][avatarY][targetX][targetY];
    }

}


